//
//  PasswordTableViewCell.swift
//  PassLock
//
//  Created by Kyle Bittner on 5/3/18.
//  Copyright © 2018 Kyle Bittner. All rights reserved.
//

import UIKit

class PasswordTableViewCell: UITableViewCell {
    @IBOutlet weak var TypeLabel: UILabel!
    @IBOutlet weak var UsernameLabel: UILabel!
    @IBOutlet weak var PasswordLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
