//
//  PasswordTableViewController.swift
//  PassLock
//
//  Created by Kyle Bittner on 5/3/18.
//  Copyright © 2018 Kyle Bittner. All rights reserved.
//

import UIKit
import CoreData
class PasswordTableViewController: UITableViewController, UINavigationControllerDelegate {

    var passwords = [Passwords]()
    var managedObjectContext:NSManagedObjectContext!
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        loadData()

        
        
    }
    
    func loadData(){
        let passwordRequest:NSFetchRequest<Passwords> = Passwords.fetchRequest()
        
        do{
            passwords = try managedObjectContext.fetch(passwordRequest)
            self.tableView.reloadData()
        }catch{
            print("Error Occured")
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return passwords.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! PasswordTableViewCell

        let passwordItem  = passwords[indexPath.row]
        cell.backgroundColor = UIColor.red
        cell.TypeLabel.text = passwordItem.type
        cell.UsernameLabel.text = passwordItem.username
        cell.PasswordLabel.text = passwordItem.password
        // Configure the cell...

        return cell
    }
    
    @IBAction func addPassword(_ sender: Any) {
        self.createPasswordItem()
        
        
    }
    func createPasswordItem(){
     
        let passwordItem = Passwords(context: managedObjectContext)
        let alert = UIAlertController(title:"New Password", message: "Enter a new Password", preferredStyle : .alert)
        
        alert.addTextField{(textfield:UITextField) in
            textfield.placeholder="Account Type"
        }
     
        alert.addTextField{(textfield:UITextField) in
            textfield.placeholder="Username"
        }
        alert.addTextField{(textfield:UITextField) in
            textfield.placeholder="Password"
        }
       
        alert.addAction(UIAlertAction(title: "Save", style:.default, handler: {(action:UIAlertAction)in
         
            let TypeField = alert.textFields![0] as UITextField
            
            let UsernameField = alert.textFields![1] as UITextField
            
            let PasswordField = alert.textFields![2] as UITextField
          
            if TypeField.text != "" && UsernameField.text != "" && PasswordField.text != ""{
                
                passwordItem.type = TypeField.text
                passwordItem.type = UsernameField.text
                passwordItem.type = TypeField.text
                
                do{
                    try self.managedObjectContext.save()
                }catch{
                    print("error")
                }
            }
        }))
        alert.addAction(UIAlertAction(title:"cancel", style: .cancel, handler:nil))
        self.present(alert, animated:true, completion: nil)
    }
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
